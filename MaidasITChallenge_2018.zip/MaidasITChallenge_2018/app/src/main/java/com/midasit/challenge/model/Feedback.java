package com.midasit.challenge.model;

import java.util.Date;

public class Feedback {

    public String feedbackId;
    public User user;
    public String content;
    public Date createdDate;

}
