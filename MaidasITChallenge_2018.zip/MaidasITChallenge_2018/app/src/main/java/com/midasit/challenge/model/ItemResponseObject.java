package com.midasit.challenge.model;

import java.util.ArrayList;

/**
 * Created by ichaeeun on 2018. 5. 26..
 */

public class ItemResponseObject {
    public int err;
    public ArrayList<Item> data;

}