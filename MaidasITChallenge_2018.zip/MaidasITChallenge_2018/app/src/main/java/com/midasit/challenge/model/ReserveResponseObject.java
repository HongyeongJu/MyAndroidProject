package com.midasit.challenge.model;

import java.util.ArrayList;

/**
 * Created by ichaeeun on 2018. 5. 27..
 */

public class ReserveResponseObject {
    public int err;
    public ArrayList<Reserve> data;


}
