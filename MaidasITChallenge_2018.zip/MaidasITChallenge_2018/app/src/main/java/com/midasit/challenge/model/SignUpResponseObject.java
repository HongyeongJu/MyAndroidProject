package com.midasit.challenge.model;

/**
 * Created by ichaeeun on 2018. 5. 21..
 */

public class SignUpResponseObject {
    public int err;
    public Object data;
}
