package com.midasit.challenge.model;

import java.util.ArrayList;

/**
 * Created by ichaeeun on 2018. 5. 26..
 */

public class UserResponseObject {
    public int err;
    public ArrayList<User> data;

}