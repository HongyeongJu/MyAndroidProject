package com.midasit.challenge.model;

import java.util.ArrayList;

/**
 * Created by ichaeeun on 2018. 5. 27..
 */

public class PurchasesResponseObject {
    public int err;
    public ArrayList<Purchase> data;


}
